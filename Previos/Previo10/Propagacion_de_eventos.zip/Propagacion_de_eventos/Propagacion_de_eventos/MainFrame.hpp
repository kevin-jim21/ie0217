// Archivo para declarar metodos para el Frame Principal

#include <wx/wx.h>

class MainFrame : public wxFrame {
public:
	MainFrame(const wxString& title);  // Tipo especial de string para wxWidgets
private:
	// Declaracion de funciones para detectar eventos
	void OnAnyButtonClicked(wxCommandEvent& evt);
	void OnButton1Clicked(wxCommandEvent& evt);
	void OnButton2Clicked(wxCommandEvent& evt);
	void OnClose(wxCloseEvent& evt);

};