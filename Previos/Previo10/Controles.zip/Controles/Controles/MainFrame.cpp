// En este archivo se definen todos los elementos que perteneceran al panel

#include "MainFrame.hpp"
#include <wx/wx.h>
#include <wx/spinctrl.h>

// Heredar de la clase wxFrame, utilizando puntero nulo y ID generico con macro de wxWidgets
MainFrame::MainFrame(const wxString& title) : wxFrame(nullptr, wxID_ANY, title) {
	wxPanel* panel = new wxPanel(this);  // Widget principal en donde se colocan los elementos
	
	// Inclusion de los demas elementos dentro del panel
	wxButton* button = new wxButton(panel, wxID_ANY, "Button", wxPoint(150, 50), wxSize(100, 35));
	wxCheckBox* checkBox = new wxCheckBox(panel, wxID_ANY, "CheckBox", wxPoint(550, 55));
	wxStaticText* staticText = new wxStaticText(panel, wxID_ANY, "StaticText - NON editable", wxPoint(120, 150));
	wxTextCtrl* textCtrl = new wxTextCtrl(panel, wxID_ANY, "TextCtrl - editable", wxPoint(500, 145), wxSize(200, -1));
	wxSlider* slider = new wxSlider(panel, wxID_ANY, 25, 0, 100, wxPoint(100, 250), wxSize(200, -1));

	// Barra de progreso
	wxGauge* gauge = new wxGauge(panel, wxID_ANY, 100, wxPoint(500, 255), wxSize(200, -1));
	gauge->SetValue(50);  // Setear al 50%

	// Item de seleccion
	wxArrayString choices;
	choices.Add("Item A");
	choices.Add("Item B");
	choices.Add("Item C");

	wxChoice* choice = new wxChoice(panel, wxID_ANY, wxPoint(150, 375), wxSize(100, -1), choices);
	choice->Select(0);  // Eleccion por defecto

	wxSpinCtrl* spintCtrl = new wxSpinCtrl(panel, wxID_ANY, "", wxPoint(500, 375), wxSize(100, -1));
	wxListBox* listBox = new wxListBox(panel, wxID_ANY, wxPoint(150, 475), wxSize(100, -1), choices);
	wxRadioBox* radioBox = new wxRadioBox(panel, wxID_ANY, "RadioBox", wxPoint(485, 475), wxDefaultSize, choices);
}