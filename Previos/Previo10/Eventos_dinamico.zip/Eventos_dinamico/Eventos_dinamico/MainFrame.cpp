#include "MainFrame.hpp"
#include <wx/wx.h>

MainFrame::MainFrame(const wxString& title) : wxFrame(nullptr, wxID_ANY, title) {
	wxPanel* panel = new wxPanel(this);  // Widget principal en donde se colocan los elementos

	// Inclusion de los demas elementos dentro del panel
	wxButton* button = new wxButton(panel, wxID_ANY, "Button", wxPoint(300, 275), wxSize(200, 50));
	wxSlider* slider = new wxSlider(panel, wxID_ANY, 0, 0, 100, wxPoint(300, 200), wxSize(200, -1));
	wxTextCtrl* text = new wxTextCtrl(panel, wxID_ANY, "", wxPoint(300, 375), wxSize(200, -1));

	// Utilizar bind
	button->Bind(wxEVT_BUTTON, &MainFrame::OnButtonClicked, this);
	slider->Bind(wxEVT_SLIDER, &MainFrame::OnSliderChanged, this);
	button->Bind(wxEVT_TEXT, &MainFrame::OnTextChanged, this);

	// Desenlazar el bind
	button->Unbind(wxEVT_BUTTON, &MainFrame::OnButtonClicked, this);

	CreateStatusBar();  // Crea una ventana de informacion acerca de los procesos del programa
}

// Definicion de las funciones detectoras de eventos

void MainFrame::OnButtonClicked(wxCommandEvent& evt) {
	wxLogStatus("Button Clicked");  // Retornar estado del evento en la StatusBar
}

void MainFrame::OnSliderChanged(wxCommandEvent& evt) {
	wxString str = wxString::Format("Slider Value: %d", evt.GetInt());  // Tomar string de tipo wx
	wxLogStatus(str);  // Retornar el estado del slider en la StatusBar
}

void MainFrame::OnTextChanged(wxCommandEvent& evt) {
	wxString str = wxString::Format("Text: %s", evt.GetString());  // Tomar el texto ingresado por el usuario
	wxLogStatus(str);  // Retornar el estado del texto en la StatusBar
}
