// Declaracion de funcion principal para programa con GUI

#include "MainFrame.hpp"
#include <wx/wx.h>

MainFrame::MainFrame(const wxString& title) : wxFrame(nullptr, wxID_ANY, title) {
	wxPanel* panel = new wxPanel(this);
	wxButton* button = new wxButton(panel, wxID_ANY, "Button 1", wxPoint(300, 250), wxSize(200, 100));

	wxStatusBar* statusBar = CreateStatusBar();  // Crea una ventana de informacion acerca de los procesos del programa
	statusBar->SetDoubleBuffered(true);

	panel->Bind(wxEVT_MOTION, &MainFrame::OnMouseEvent, this);
	button->Bind(wxEVT_MOTION, &MainFrame::OnMouseEvent, this);
}

void MainFrame::OnMouseEvent(wxMouseEvent& evt) {
	wxPoint mousePos = wxGetMousePosition();  // Pos absoluta basado en la pantalla
	mousePos = this->ScreenToClient(mousePos);  // Pos relativa segun el frame
	wxString message = wxString::Format("Mouse Event Detected! (x=%d y=%d)", mousePos.x, mousePos.y);
	wxLogStatus(message);
}