// Declaracion de la clase App que contiene metodo que incializa el programa para wxWidgets

#include <wx/wx.h>

class App : public wxApp {
public:
	bool OnInit();  // Por aca es donde va a ingresar el programa al usar wxWidgets
};