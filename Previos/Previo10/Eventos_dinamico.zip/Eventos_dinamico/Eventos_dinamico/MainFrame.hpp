// Archivo en donde se define el frame principal para el programa de gui

#include <wx/wx.h>

class MainFrame : public wxFrame {
public:
	MainFrame(const wxString& title);  // Tipo especial de string para wxWidgets
private:
	// Declaracion de funciones para detectar eventos
	void OnButtonClicked(wxCommandEvent& evt);
	void OnSliderChanged(wxCommandEvent& evt);
	void OnTextChanged(wxCommandEvent& evt);

};