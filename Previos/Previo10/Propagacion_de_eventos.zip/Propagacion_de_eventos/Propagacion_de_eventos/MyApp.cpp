// Archivo donde se define la funcion principal para el programa GUI

#include "MyApp.hpp"
#include "MainFrame.hpp"

wxIMPLEMENT_APP(App);

bool App::OnInit() {
	MainFrame* mainframe = new MainFrame("C++ GUI");

	mainframe->Show();
	return true;
}